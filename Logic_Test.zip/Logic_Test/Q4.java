package Logic_Test;

import java.util.Scanner;

public class Q4 {

    public static void main(String [] args){
    
        int n;
        int a=0;
        int b=1;
        int c;
  
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number");
        n=sc.nextInt();
        for(int i=1;i<=n;i++){
            System.out.println(a+" ");
            c=a+b;
            a=b;
            b=c;
        }
        sc.close();
    }
    
}
