package Logic_Test;

import java.util.Scanner;

public class Q1 {

    public static void main(String[] args){

        int a;
        Scanner sc=new Scanner (System.in);
        System.out.println("Enter the number");
        a=sc.nextInt();

        if(a%3==0){
            System.out.println("Fun");
        }
        else if(a%7==0){
            System.out.println("Buzz");
        }
        else if(a%3==0 && a%7==0){
            System.out.println("Fun Buzz");
        }sc.close();
    }
}
