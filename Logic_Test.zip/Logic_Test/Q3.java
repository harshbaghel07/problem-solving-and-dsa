package Logic_Test;

import java.util.Scanner;

public class Q3 {
    public static void main(String [] args){
        int a,r,rev=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Number");
        a=sc.nextInt();
        int orig=a;
         while(a!=0){
            r=a%10;
            rev=rev*10+r;
            a=a/10;
           }
           if(orig==rev){
            System.out.println("Number is a palandrom");
           }
           else{
            System.out.println("The given Number is not a Palandrom");
           }
           sc.close();
    }
}
