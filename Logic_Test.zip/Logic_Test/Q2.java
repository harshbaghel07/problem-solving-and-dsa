package Logic_Test;

import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        int s;
        int e;

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the start no");
        s=sc.nextInt();

        System.out.println("Enter the End no");
        e=sc.nextInt();

        System.out.println("odd in between"+s+"and"+e+":");
        for(int i=s;i<=e;i++){
            if(i%2!=0){
                System.out.println(i+"");
            }
        }sc.close();
    }
 
}

